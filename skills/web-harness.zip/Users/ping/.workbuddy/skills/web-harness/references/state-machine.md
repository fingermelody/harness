# WebHarness 状态机工作流

本文档定义了 WebHarness 框架的核心状态机，规定了项目从想法到上线的完整生命周期。

---

## 状态定义

| 状态 | 英文标识 | 说明 | 负责角色 |
|------|----------|------|----------|
| **构想** | `IDEA` | 需求收集与分析阶段 | PM + Planner |
| **规划** | `PLAN` | 技术方案设计与任务拆解 | Planner |
| **开发** | `CODE` | 功能编码与单元测试 | Coder |
| **测试** | `TEST` | 集成测试与 E2E 验证 | Tester |
| **评估** | `EVAL` | 质量门禁与综合评分 | Evaluator |
| **部署** | `DEPLOY` | 构建发布与环境部署 | Deployer |
| **监控** | `MONITOR` | 线上观测与持续运营 | Deployer + PM |
| **归档** | `ARCHIVE` | 版本结项与经验沉淀 | 全员 |

## 状态转换图（Mermaid）

```mermaid
stateDiagram-v2
    [*] --> IDEA : 新需求 / 新 Feature
    
    IDEA --> PLAN : 需求评审通过
    IDEA --> IDEA : 需求不明确（退回澄清）
    
    PLAN --> CODE : 方案审批通过 + 任务拆解完成
    PLAN --> PLAN : 技术风险未解决
    PLAN --> IDEA : 方案不可行（取消/重定义）
    
    CODE --> TEST : 开发完成 + 自测通过
    CODE --> CODE : Code Review 不通过
    CODE --> PLAN : 需求变更 / 方案调整
    
    TEST --> EVAL : 全部测试用例通过
    TEST --> TEST : 发现 Bug（修复→回归）
    TEST --> CODE : 需要重大重构
    
    EVAL --> DEPLOY : 评分 ≥ 80 (PASS)
    EVAL --> TEST : 评分 60-79 (WARN) → 修复后重新评估
    EVAL --> CODE : 评分 < 60 (BLOCK) → 打回重构
    
    DEPLOY --> MONITOR : 部署成功 + Health Check 通过
    DEPLOY --> DEPLOY : 部署失败 → 回滚
    DEPLOY --> EVAL : 预发布发现问题
    
    MONITOR --> IDEA : 新需求 / 迭代开始
    MONITOR --> ARCHIVE : 项目结项 / 版本归档
    
    ARCHIVE --> [*]
```

## 转换守卫规则（Guard Conditions）

### IDEA → PLAN（需求评审门）
**前置条件（全部满足才允许转换）：**
- [ ] PM 已录入需求到 Backlog
- [ ] Planner 已完成需求澄清（≤ 3 轮追问）
- [ ] 验收标准（AC）已明确定义
- [ ] 技术可行性初步确认

**转换动作：**
- 创建 `docs/plan/[feature-id]/` 目录
- 生成初始 ADR（架构决策记录）

### PLAN → CODE（方案审批门）
**前置条件：**
- [ ] 技术方案文档已完成（≥ 2 个备选方案对比）
- [ ] API 契约已定义（OpenAPI/Swagger）
- [ ] 任务已拆解为 Story + Task（含估算）
- [ ] PM 已确认优先级和排期
- [ ] 技术风险已识别并有缓解策略

**转换动作：**
- 创建 Issue/Task 跟踪
- 分配给 Coder
- 通知 Tester 准备测试策略

### CODE → TEST（开发完成门）
**前置条件：**
- [ ] 所有 Story Task 标记 Done
- [ ] Unit Test 覆盖率 ≥ 目标值（默认 80%）
- [ ] Code Review 至少 1 人 Approval
- [ ] Lint + Format 全部通过
- [ ] 无 P0/P1 阻塞性 TODO

**转换动作：**
- 提交 PR/MR 到测试分支
- 触发 CI 构建
- 通知 Tester 开始测试

### TEST → EVAL（测试完成门）
**前置条件：**
- [ ] E2E 主流程 100% 通过
- [ ] 单元/集成测试全部通过
- [ ] 无 P0 Bug，P1 Bug ≤ 2 个且有 workaround
- [ ] 性能测试符合基线（LCP < 2.5s, FID < 100ms）
- [ ] 安全扫描无 CRITICAL/HIGH 漏洞
- [ ] a11y audit 得分 ≥ 90

**转换动作：**
- 生成测试报告
- 收集截图和日志证据
- 触发 Evaluator

### EVAL → DEPLOY（质量放行门）
**前置条件：**
- [ ] 综合评分 ≥ 80（PASS）
- [ ] 所有质量维度无 BLOCK 项
- [ ] CHANGELOG 已更新
- [ ] 版本号符合 semver
- [ ] PM 已确认发布窗口

**转换动作：**
- 签署发布许可
- 通知 Deployer 准备发布

### DEPLOY → MONITOR（上线门）
**前置条件：**
- [ ] Staging 环境 Smoke Test 通过
- [ ] 数据库迁移脚本已准备并可回滚
- [ ] 特性开关（Feature Flag）就绪（如需灰度）
- [ ] 回滚方案已确认（≤ 5min RTO）

**转换动作：**
- 执行部署（按策略：金丝雀/蓝绿/rolling）
- 运行 Health Check
- 确认关键路径可用

### 异常回退策略

| 当前状态 | 异常场景 | 目标状态 | 处理方式 |
|----------|----------|----------|----------|
| PLAN | 技术方案不可行 | IDEA | 取消或重定义需求 |
| CODE | 需求重大变更 | PLAN | 重新进入规划流程 |
| TEST | 发现架构缺陷 | CODE | 重构后再测 |
| EVAL | BLOCK (< 60分) | CODE | 打回重构，Planner 辅助 |
| DEPLOY | 部署失败 | EVAL | 回滚，重新评估 |
| MONITOR | 线上 P0 事故 | DEPLOY | 紧急 Hotfix |
| 任意 | 取消 | ARCHIVE | 记录原因，沉淀经验 |

## 角色在各状态下的权责矩阵

| 状态 | PM | Planner | Coder | Tester | Evaluator | Deployer |
|------|----|---------|-------|--------|-----------|----------|
| IDEA | 👑 主导 | ⭐ 参与 | | | | |
| PLAN | ⭐ 确认 | 👑 主导 | 💬 评审 | | | |
| CODE | 📊 跟踪 | 💬 支持 | 👑 主导 | 📝 准备 | | |
| TEST | 📊 跟踪 | | 💬 协助 | 👑 主导 | | |
| EVAL | 📋 决策 | | 📋 输入 | 📋 输入 | 👑 主导 | |
| DEPLOY | ✅ 批准 | | | ✅ 许可 | 👑 主导 | |
| MONITOR | 👁️ 关注 | | | | 👁️ 关注 | 👑 主导 |

图例：👑主导 / ⭐参与 / 💬咨询 / 📋输入 / 📊跟踪 / ✅审批 / 👁️关注

## 状态持久化

每次状态转换必须记录到 `docs/state-log.md`：

```markdown
## [timestamp] STATE_TRANSITION

- **from**: PLAN
- **to**: CODE
- **trigger**: 方案审批通过 (PR #42 merged)
- **actor**: PM (@ping)
- **artifacts**: docs/plan/auth-system/, issues #43-#50
- **guard_check**: ✅ All 5 conditions met
- **notes**: 采用 JWT 方案，预计 3 天完成
```
