# WebHarness 验证机制（质量门禁系统）

本文档定义了多层质量门禁规则，确保每个阶段的交付物都达到预期标准。

---

## 门禁层级总览

```
  Commit 级门禁           PR 级门禁            Release 级门禁
┌──────────────┐   ┌──────────────┐    ┌──────────────────┐
│  Lint Check   │   │  Full Test   │    │  E2E Regression   │
│  Format Check │ → │  Sec Scan    │ → │  Perf Baseline    │
│  Unit Test    │   │  Code Review │    │  Smoke Test       │
│              │   │              │    │  Accessibility    │
│  ~30 秒      │   │  ~5 分钟     │    │  ~15 分钟        │
└──────────────┘   └──────────────┘    └──────────────────┘
```

---

## Level 1：Commit 级门禁（~30 秒）

**目标**：保证每一次提交都不会破坏基本构建。

**触发时机**：每次 `git push` 或 PR 创建时自动触发。

### 检查清单

| # | 检查项 | 工具 | 严格度 | 失败处理 |
|---|--------|------|--------|----------|
| 1.1 | 代码风格 (Lint) | ESLint / Pylint / Ruff | **BLOCK** | PR 无法合并 |
| 1.2 | 代码格式化 | Prettier / Black | **BLOCK** | auto-fix 后 re-push |
| 1.3 | 单元测试 | vitest / pytest | **BLOCK** | 新增代码需有测试覆盖 |
| 1.4 | Type 检查 | tsc --noEmit / pyright | **BLOCK** | 类型错误必须修复 |
| 1.5 | Commit Message | commitlint | WARN | 不阻止但标记不规范 |
| 1.6 | 文件大小限制 | custom script | WARN | 单文件 < 500 行 (新文件) |
| 1.7 | 无敏感信息 | git-secrets / trufflehog | **BLOCK** | 检测到密钥/Token 立即阻断 |

### CI 配置片段（GitHub Actions 示例）

```yaml
# .github/workflows/commit-gate.yml
name: Commit Gate
on: [push, pull_request]
jobs:
  commit-gate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Setup Node/Python
        uses: actions/setup-node@v4  # or setup-python@v5
        
      - name: Install dependencies
        run: npm ci  # or pip install -r requirements.txt
        
      - name: Lint
        run: npm run lint  # or ruff check .
        
      - name: Format Check
        run: npm run format:check  # or black --check .
        
      - name: Type Check
        run: npm run typecheck  # or pyright .
        
      - name: Unit Test
        run: npm run test:unit  # or pytest tests/unit/ --cov=src
        
      - name: Secret Scan
        uses: trufflesecurity/trufflehog@v3
        with:
          path: ./ 
          base: ${{ github.event.repository.default_branch }}
          head: HEAD
```

---

## Level 2：PR 级门禁（~5 分钟）

**目标**：确保合入主分支的代码经过充分验证。

**触发时机**：PR 准备合并前（或 label 为 `ready-to-merge` 时）。

### 检查清单

| # | 检查项 | 工具 | 严格度 | 失败处理 |
|---|--------|------|--------|----------|
| 2.1 | 全量单元+集成测试 | vitest / pytest | **BLOCK** | 覆盖率不达标不能合并 |
| 2.2 | 测试覆盖率门槛 | istanbul / coverage | **BLOCK** | 新增代码 Δcoverage ≥ 80% |
| 2.3 | 安全扫描 | Snyk / CodeQL / Semgrep | **BLOCK** | CRITICAL/HIGH 必须修 |
| 2.4 | Code Review | GitHub Review / CR Bot | **BLOCK** | 至少 1 Approval, 0 Change Request |
| 2.5 | 构建产物检查 | build script | **BLOCK** | 生产构建成功 |
| 2.6 | API 契约验证 | Pact / openapi-diff | WARN | Breaking Change 需要明确标注 |
| 2.7 | 变更影响分析 | (AI 辅助) | INFO | 供 reviewer 参考 |

### Code Review 规范

**Reviewer 必须检查：**
- [ ] 逻辑正确性（是否实现预期功能）
- [ ] 边界情况处理
- [ ] 性能影响（是否有 N+1/O(n²) 问题）
- [ ] 安全隐患（注入/XSS/权限）
- [ ] 测试充分性
- [ ] 可维护性和命名
- [ ] 是否有更简洁的实现

**Review 分类标签：**
- `🟢 LGTM` — 直接批准
- `🟡 Minor` — 小问题，可以后续改（Nits）
- `🔴 Request Changes` — 必须修改后重新 review

---

## Level 3：Release 级门禁（~15 分钟）

**目标**：保证发布到生产的版本达到上线质量标准。

**触发时机**：创建 Release Tag 或合并到 release 分支时。

### 检查清单

| # | 检查项 | 工具 | 严格度 | 失败处理 |
|---|--------|------|--------|----------|
| 3.1 | E2E 回归测试 | Playwright (无 mock) | **BLOCK** | 关键路径 0 失败 |
| 3.2 | 性能基线对比 | Lighthouse CI / k6 | **BLOCK** | 退化超过阈值则阻断 |
| 3.3 | Smoke Test (Staging) | 自动化脚本 | **BLOCK** | 核心功能可用 |
| 3.4 | a11y 审计 | axe-core | WARN | 得分 < 90 需记录技术债 |
| 3.5 | 视觉回归 | Playwright screenshots | WARN | 差异需人工确认 |
| 3.6 | 兼容性测试 | BrowserStack / LT | **BLOCK** | 目标浏览器矩阵全通过 |
| 3.7 | 数据库迁移验证 | migrate + rollback test | **BLOCK** | 迁移可逆且无损 |
| 3.8 | CHANGELOG 完整性 | changelog checker | **BLOCK** | 所有 user-facing 变更已记录 |

### E2E 测试关键路径（必测）

任何 WebApp 发布 **至少** 覆盖以下关键路径：

| # | 用户路径 | 优先级 | 测试方法 |
|---|----------|--------|----------|
| 1 | 注册/登录流程 | P0 | 完整表单提交 + 验证 |
| 2 | 核心功能 CRUD | P0 | Create → Read → Update → Delete |
| 3 | 搜索与过滤 | P0 | 输入 → 结果 → 排序 |
| 4 | 分页与加载更多 | P1 | 边界页码/空状态 |
| 5 | 文件上传/下载 | P1 | 大文件/断网/取消 |
| 6 | 权限边界 | P0 | 未授权访问被拒绝 |
| 7 | 错误场景 | P1 | 404/500/网络异常的优雅降级 |
| 8 | 移动端适配 | P1 | 触摸交互 + 视口切换 |

---

## 门禁判定引擎

### 三级判决逻辑

```python
# 伪代码 — 门禁判定
def evaluate_gate(level: str, checks: list[CheckResult]) -> GateVerdict:
    """
    checks = [
        CheckResult(name="Lint", status="pass", severity="block"),
        CheckResult(name="Secret Scan", status="fail", severity="block"),
        ...
    ]
    """
    
    blocks_failed = [c for c in checks if c.severity == "block" and c.status == "fail"]
    warns_failed  = [c for c in checks if c.severity == "warn"  and c.status == "fail"]
    
    if blocks_failed:
        return GateVerdict(
            verdict="BLOCK",
            reason=f"阻塞项: {[c.name for c in blocks_failed]}",
            can_force=False,  # 不允许强制通过
            actions=[Fix(c) for c in blocks_failed]
        )
    elif warns_failed:
        return GateVerdict(
            verdict="WARN",
            reason=f"警告项: {[c.name for c in warns_failed]}",
            can_force=True,  # PM 可确认后放行
            actions=[Acknowledge(c) for c in warns_failed],
            condition="pm_approval_required"
        )
    else:
        return GateVerdict(
            verdict="PASS",
            reason="所有门禁检查通过",
            can_force=True,
            actions=[]
        )
```

### 判决结果处理

| 判决 | 含义 | 流程 |
|------|------|------|
| **PASS** ✅ | 所有检查通过 | 进入下一阶段 |
| **WARN** ⚠️ | 有警告项但无阻塞 | PM 确认后可继续；警告记入技术债 |
| **BLOCK** 🚫 | 存在阻塞项 | **停止流水线**，通知相关角色修复后重新触发 |

### 紧急 Hotfix 通道

生产 P0 故障时，可走紧急通道：
1. PM 发起紧急发布申请（附事故单号）
2. 跳过 Level 2 部分非必要检查（保留 Lint + Unit Test + Security）
3. Level 3 仅做 Smoke Test（关键路径 3 条以内）
4. 事后 24h 内补齐所有跳过的检查
5. 记录到 `docs/post-mortem/`

---

## 门禁配置文件

项目根目录下的 `.gates.yml` 定义所有门禁规则：

```yaml
# .gates.yml — WebHarness 质量门禁配置
version: "1.0"

levels:
  commit:
    timeout: "30s"
    checks:
      - name: lint
        tool: eslint / ruff
        severity: block
      - name: format
        tool: prettier / black
        severity: block
      - name: unit-test
        tool: vitest / pytest
        severity: block
        params:
          min_coverage_delta: 80  # 新增代码最低覆盖率
      - name: type-check
        tool: tsc / pyright
        severity: block
      - name: secret-scan
        tool: trufflehog
        severity: block
      - name: commit-msg
        tool: commitlint
        severity: warn

  pr:
    timeout: "5m"
    requires_commit_gate: true
    checks:
      - name: full-test
        tool: vitest / pytest
        severity: block
        params:
          coverage_threshold: 80
      - name: security
        tool: snyk / codeql
        severity: block
      - name: code-review
        tool: github-review-api
        severity: block
        params:
          min_approvers: 1
          block_change_requests: true
      - name: build
        tool: npm run build / python -m build
        severity: block
      - name: api-contract
        tool: pact / openapi-diff
        severity: warn

  release:
    timeout: "15m"
    requires_pr_gate: true
    checks:
      - name: e2e-regression
        tool: playwright
        severity: block
        params:
          mode: no-mock  # 禁用 mock
          critical_paths_only: true
      - name: performance
        tool: lighthouse-ci / k6
        severity: block
        params:
          lcp_budget: 2500  # ms
          regression_threshold: 10  # % 允许退化
      - name: smoke-test
        tool: scripts/smoke-test.sh
        severity: block
        env: staging
      - name: accessibility
        tool: axe-core
        severity: warn
        params:
          min_score: 90
      - name: changelog
        tool: changelog-checker
        severity: block
      - name: db-migration
        tool: migrate-verify
        severity: block
        params:
          require_rollback_test: true

hotfix:
  skip_checks:
    - code-review      # 改为 1 人 quick-approve
    - e2e-regression   # 缩减为 3 条关键路径
    - accessibility    # 跳过
    - visual-regression # 跳过
  always_required:
    - lint
    - unit-test
    - security
    - smoke-test
  post_hoard_deadline: "24h"  # 事后补齐时限
```
